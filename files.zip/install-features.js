#!/usr/bin/env node
/**
 * CA Financial Assist - Auto Feature Installer
 * Run: node install-features.js
 * This script copies all new feature files into the right places
 * and updates App.tsx routes automatically.
 */

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const ROOT = process.cwd();
const SRC = path.join(ROOT, "src");
const TOOLS_DIR = path.join(SRC, "pages", "tools");
const HOOKS_DIR = path.join(SRC, "hooks");
const COMPONENTS_DIR = path.join(SRC, "components");

// ─── Create directories ───────────────────────────────────────────────────────
[TOOLS_DIR, HOOKS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log("✅ Created directory:", dir);
  }
});

// ─── Files to copy ────────────────────────────────────────────────────────────
// Copy these from current directory (where you run the script)
const FILES = [
  { src: "BankAnalyzer.tsx",        dest: path.join(TOOLS_DIR, "BankAnalyzer.tsx") },
  { src: "LBOAnalyzer.tsx",         dest: path.join(TOOLS_DIR, "LBOAnalyzer.tsx") },
  { src: "InvestmentAnalyzer.tsx",  dest: path.join(TOOLS_DIR, "InvestmentAnalyzer.tsx") },
  { src: "FinancialCalculators.tsx",dest: path.join(TOOLS_DIR, "FinancialCalculators.tsx") },
  { src: "TaxOptimizer.tsx",        dest: path.join(TOOLS_DIR, "TaxOptimizer.tsx") },
  { src: "KeyboardShortcuts.tsx",   dest: path.join(SRC, "components", "KeyboardShortcuts.tsx") },
  { src: "OnboardingTour.tsx",      dest: path.join(SRC, "components", "OnboardingTour.tsx") },
  { src: "FinancialHealthScore.tsx",dest: path.join(SRC, "components", "FinancialHealthScore.tsx") },
];

FILES.forEach(({ src, dest }) => {
  const srcPath = path.join(ROOT, src);
  if (fs.existsSync(srcPath)) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(srcPath, dest);
    console.log("✅ Copied:", src, "→", dest.replace(ROOT, ""));
  } else {
    console.log("⚠️  File not found (skip):", src);
  }
});

// ─── Find and patch App.tsx ───────────────────────────────────────────────────
const appPath = path.join(SRC, "App.tsx");
if (!fs.existsSync(appPath)) {
  console.log("⚠️  App.tsx not found at", appPath);
  console.log("   Manually add routes listed below.");
} else {
  let app = fs.readFileSync(appPath, "utf8");

  const imports = `
// ── New Tool Pages ─────────────────────────────────────────────────
import BankAnalyzer from "./pages/tools/BankAnalyzer";
import LBOAnalyzer from "./pages/tools/LBOAnalyzer";
import InvestmentAnalyzer from "./pages/tools/InvestmentAnalyzer";
import FinancialCalculators from "./pages/tools/FinancialCalculators";
import TaxOptimizer from "./pages/tools/TaxOptimizer";
`;

  const routes = `
        {/* ── New Tool Routes ─────────────────────────────────────── */}
        <Route path="/tools/bank-analyzer" element={<BankAnalyzer />} />
        <Route path="/tools/lbo" element={<LBOAnalyzer />} />
        <Route path="/tools/investment" element={<InvestmentAnalyzer />} />
        <Route path="/tools/calculators" element={<FinancialCalculators />} />
        <Route path="/tools/tax-optimizer" element={<TaxOptimizer />} />
`;

  // Add imports if not already present
  if (!app.includes("BankAnalyzer")) {
    // Find last import line and add after it
    const lastImport = app.lastIndexOf("\nimport ");
    const endOfImports = app.indexOf("\n", lastImport + 1);
    app = app.slice(0, endOfImports + 1) + imports + app.slice(endOfImports + 1);
    console.log("✅ Added imports to App.tsx");
  } else {
    console.log("ℹ️  Imports already exist in App.tsx");
  }

  // Add routes if not already present
  if (!app.includes("/tools/bank-analyzer")) {
    // Find </Routes> and insert before it
    const routesEnd = app.lastIndexOf("</Routes>");
    if (routesEnd !== -1) {
      app = app.slice(0, routesEnd) + routes + "\n        " + app.slice(routesEnd);
      console.log("✅ Added routes to App.tsx");
    } else {
      console.log("⚠️  Could not find </Routes> in App.tsx — add routes manually");
    }
  } else {
    console.log("ℹ️  Routes already exist in App.tsx");
  }

  fs.writeFileSync(appPath, app);
  console.log("✅ App.tsx updated");
}

// ─── Update index.html ────────────────────────────────────────────────────────
const indexPath = path.join(ROOT, "index.html");
if (fs.existsSync(indexPath)) {
  let html = fs.readFileSync(indexPath, "utf8");
  if (html.includes("Lovable App")) {
    html = html
      .replace(/Lovable App/g, "CA Financial Assist")
      .replace(/Lovable Generated Project/g, "Professional CA Financial Management Platform");
    fs.writeFileSync(indexPath, html);
    console.log("✅ Updated index.html title");
  }
}

// ─── Update package.json name ────────────────────────────────────────────────
const pkgPath = path.join(ROOT, "package.json");
if (fs.existsSync(pkgPath)) {
  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
  if (pkg.name !== "ca-financial-assist") {
    pkg.name = "ca-financial-assist";
    fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2));
    console.log("✅ Updated package.json name");
  }
}

// ─── Ensure .gitignore has .env ───────────────────────────────────────────────
const gitignorePath = path.join(ROOT, ".gitignore");
if (fs.existsSync(gitignorePath)) {
  let gitignore = fs.readFileSync(gitignorePath, "utf8");
  const additions = [];
  if (!gitignore.includes(".env")) additions.push(".env");
  if (!gitignore.includes(".env.local")) additions.push(".env.local");
  if (!gitignore.includes(".env.*.local")) additions.push(".env.*.local");
  if (additions.length) {
    gitignore += "\n# Environment variables\n" + additions.join("\n") + "\n";
    fs.writeFileSync(gitignorePath, gitignore);
    console.log("✅ Updated .gitignore with .env entries");
  }
}

// ─── Git commit and push ──────────────────────────────────────────────────────
console.log("\n📦 Committing and pushing to GitHub...");
try {
  execSync("git add .", { stdio: "inherit", cwd: ROOT });
  execSync('git commit -m "feat: add LBO, investment tools, bank analyzer, calculators, AI tax optimizer, onboarding, keyboard shortcuts"', { stdio: "inherit", cwd: ROOT });
  execSync("git push", { stdio: "inherit", cwd: ROOT });
  console.log("\n🎉 Successfully pushed to GitHub!");
} catch (err) {
  console.log("\n⚠️  Git push failed. Run these manually:");
  console.log("   git add .");
  console.log('   git commit -m "feat: add premium features"');
  console.log("   git push");
}

console.log("\n✨ Installation complete!");
console.log("   Run: npm run dev");
console.log("   New routes available:");
console.log("   → /tools/bank-analyzer");
console.log("   → /tools/lbo");
console.log("   → /tools/investment");
console.log("   → /tools/calculators");
console.log("   → /tools/tax-optimizer");
